var api=chrome.extension.getBackgroundPage().api
function add(){
	api.addCurrent()
	window.close();
}
function openSpeedDial(){
	chrome.tabs.create({url:'speeddial.html',selected:true})
	window.close()
}
document.addEventListener( "DOMContentLoaded", function(){
	document.getElementById('menu_open').addEventListener('click',openSpeedDial);
	document.getElementById('menu_add').addEventListener('click',add);
}, false );