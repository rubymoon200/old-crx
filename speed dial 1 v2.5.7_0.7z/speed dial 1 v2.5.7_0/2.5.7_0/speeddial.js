$(document).ready(function(){
	prepare();
	$('#minimize-button').click(function(){
		minimize();
		return false;
	});
	if (localStorage.recommendFT == undefined){
		$('#sdfoxtab').show();
		$('#sdfoxtab a').click(function(e){
			localStorage.recommendFT = true;
			//console.log(e.currentTarget.href);
			document.location = e.currentTarget.href;
			return false;
		})
	}
	$('#options-button').click(openOptions);
	$('#themes.white').click(function(){setTheme(0)});
	$('#themes.blue').click(function(){setTheme(1)});
	$('#themes.red').click(function(){setTheme(2)});
	$('#themes.green').click(function(){setTheme(3)});
	$('#themes.orange').click(function(){setTheme(4)});
	$('#themes.purple').click(function(){setTheme(5)});
	$('#themes.black').click(function(){setTheme(6)});
	$('#displayBBCheckBox').click(toggleBB);
	$('#displayRCCheckBox').click(toggleRC);
	$('#displayTitleCheckBox').click(toggleTitle);
	$('#displayPageIconCheckBox').click(togglePageIcon);
	$('#save-n-close').click(openOptions);
	$('#md-0').mousedown(function(){menuClick(0);});
	$('#md-1').mousedown(function(){menuClick(1);});
	$('#md-2').mousedown(function(){menuClick(2);});
	$('#md-3').mousedown(function(){menuClick(3);});
	$('#optbgset').click(saveBackgroundImage);
	$('#optbgclear').click(clearBackgroundImage);
	$('#dialRefreshMode').change(function(ev){onDialRefrehsModeChanged(ev)});
	$('#addPageShortcut').change(function(ev){onAddPageShortcutChanged(ev)});
	$('#selectRows').change(function(ev){dialsNumberChanged(ev, 0)});
	$('#selectCols').change(function(ev){dialsNumberChanged(ev, 1)});	
});