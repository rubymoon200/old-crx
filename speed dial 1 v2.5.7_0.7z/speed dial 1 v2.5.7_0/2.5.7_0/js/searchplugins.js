function loadResource(resource,type){
	try{
		var xhr = new XMLHttpRequest();
		xhr.open("GET", chrome.extension.getURL(resource), false);
		xhr.send();
		if (type == 'xml')
			return xhr.responseXML;
		else
			return JSON.parse(xhr.responseText);
	}catch(e){console.log(e)}
}

var searchplugins = (function(){
	var m_engines = loadResource('resources/searchengines.json');
	var m_webEngines = loadResource('resources/websearchengines.json');


	var defEngine = {
	  ShortName: chrome.i18n.getMessage("Web"),
	  LongName : "Google Search",
	  Image: "data:image/gif;base64,R0lGODlhEAAQAPcAAAAAAGRkZGVlZWZmZmdnZ2hoaGlpaWpqanBwcHFxcXd3d3h4eHl5eXp6enx8fH19fX5+fn9/f4eHh5iYmJmZmZubm52dnaampqurq66urq+vr7CwsLGxsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAP8ALAAAAAAQABAAAAhoAP8JHEiwoMGDBzkwIMBgA0KBEgJAmOAggASEGgI4FJghgIaDCiIUfKDg4IAKBSkIOLhAJEGSBzd4HNjx48GIDygGCIDhIYcGBhpwuBAAwcOCCAIcOEqwQAADTAcaCJAgqsAEFqwWDAgAOw==",
	  InputEncoding : "UTF-8",
	  SearchUrl : "http://www.google.com/search?sourceid=chrome&ie=utf-8&oe=utf-8&aq=t&hl={lang}&q={searchTerms}",
	  SuggestUrl: "http://www.google.com/complete/search?client=firefox&ie=utf-8&oe=utf-8&hl={lang}&q={searchTerms}",
	  SearchForm:"https://www.google.com/"
	}
	//_engines.push(defEngine);
	//_engines = _engines.concat(engines);
	
	return {
		get : function(){
			var dws;
			if (localStorage.dws != undefined) {
				dws = this.getWebEngineByName(localStorage.dws);
			}
			if (dws == undefined) { dws = defEngine; }
			
			var r= [].concat([dws], m_engines);
			return r;
		},
		
		getEngineByName:
		function(aEngineName) {
			var engines = this.get();
			if (aEngineName == undefined)
				return engines[0];
			var result;
			engines.forEach(function(aEngine) {
				if (aEngine.ShortName == aEngineName) {
					result = aEngine;
				}
			});
			return result;
		},
		
		getWebEngineByName:
		function(aName) {
			var wEngine;
			m_webEngines.forEach(function(aEngine){
				if (aEngine.ShortName == aName) {
					wEngine = aEngine;
				}
			});
			return wEngine;
		},
		
		get webEngines() {
			return [].concat(defEngine, m_webEngines);
		},
		get webEngineName() {
			return localStorage.dws;
		},
		
		set webEngineName(aEngineName) {
			localStorage.dws = aEngineName;
		},
		
		get defaultEngine() {
			return defEngine;
		}
	}
}());